<?php
session_start();
require('./php/db.php'); 

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Gallery</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="./src/js/gallery.js" defer></script> 
</head>

<body class="min-h-screen flex bg-white">
    <?php include("./components/header.php") ?>

    <div class="flex justify-end p-4">
        <button id="toggleFormButton" onclick="toggleForm()" class="fixed bottom-6 right-6 bg-black text-white p-4 rounded-xl hover:bg-black transition duration-300">
            <svg width="25px" height="25px" viewBox="0 -0.5 25 25" class="stroke-white" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.5 10.7655C5.50003 8.01511 7.44296 5.64777 10.1405 5.1113C12.8381 4.57483 15.539 6.01866 16.5913 8.55977C17.6437 11.1009 16.7544 14.0315 14.4674 15.5593C12.1804 17.0871 9.13257 16.7866 7.188 14.8415C6.10716 13.7604 5.49998 12.2942 5.5 10.7655Z" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M17.029 16.5295L19.5 19.0005" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
    </div>

    <main class="flex flex-col w-full p-8 md:p-12">
        <div id="uploadFormContainer" class="hidden max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg">
            <h2 class="text-3xl font-semibold text-center text-gray-800 mb-6">Upload Your Photo</h2>
            <form id="uploadForm" action="php/upload.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                <div>
                    <label for="photo" class="block text-sm font-medium text-gray-700">Choose a Photo</label>
                    <input type="file" name="photo" id="photo" class="mt-2 block w-full text-sm text-gray-500 border border-gray-300 rounded-xl shadow-sm focus:ring focus:ring-black" required>
                </div>
                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700">Photo Description</label>
                    <input type="text" name="description" id="description" class="mt-2 block w-full text-sm text-gray-500 border border-gray-300 rounded-xl shadow-sm focus:ring focus:ring-black" required>
                </div>
                <button type="submit" class="w-full bg-black text-white py-3 rounded-xl hover:bg-black transition duration-300">Upload Photo</button>
            </form>
        </div>
        
        <div id="gallery" class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <?php
            
            $query = "SELECT * FROM photos";
            $result = $connect->query($query);

            while ($row = $result->fetch_assoc()) {
                
                $photoId = $row['id'];
                $author = $row['author'];
                $description = $row['description'];
                $imagePath = $row['image_path'];

                $getUserQuery = "SELECT avatar_url FROM user WHERE nickname = ?";
                $stmt = $connect->prepare($getUserQuery);
                $stmt->bind_param("s", $author);
                $stmt->execute();
                $userResult = $stmt->get_result();
                $userData = $userResult->fetch_assoc();
                $userAvatar = $userData['avatar_url'];
                
                $likeQuery = "SELECT COUNT(*) AS like_count FROM photo_likes WHERE photo_id = ?";
                $stmt = $connect->prepare($likeQuery);
                $stmt->bind_param("i", $photoId);
                $stmt->execute();
                $likeResult = $stmt->get_result();
                $likeData = $likeResult->fetch_assoc();
                $likeCount = $likeData['like_count'];
            ?>
                <div class="flex flex-col gap-2 bg-white p-2 rounded-xl">
                    <img src="<?php echo $imagePath; ?>" alt="photo" class="w-full object-cover rounded-xl mb-4">
                    <div class="flex justify-between">
                        <div class="flex gap-3">
                            <img src="<?php echo $userAvatar ? $userAvatar : "./public/profile.jpg" ?>" class="w-12 h-12 rounded-full object-cover">
                            <p class="font-semibold text-lg my-auto"><?php echo htmlspecialchars($author); ?></p>
                        </div>
                        
                        <div class="flex gap-2">
                            <div class="flex gap-2">
                                <div class="flex">
                                    <p class="my-auto text-sm opacity-60"><?php echo $likeCount ?></p>
                                    <svg width="25px" class="my-auto" height="25px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path class="opacity-60" fill="#000000" fill-rule="evenodd" clip-rule="evenodd" d="M15.0501 7.04419C15.4673 5.79254 14.5357 4.5 13.2163 4.5C12.5921 4.5 12.0062 4.80147 11.6434 5.30944L8.47155 9.75H5.85748L5.10748 10.5V18L5.85748 18.75H16.8211L19.1247 14.1428C19.8088 12.7747 19.5406 11.1224 18.4591 10.0408C17.7926 9.37439 16.8888 9 15.9463 9H14.3981L15.0501 7.04419ZM9.60751 10.7404L12.864 6.1813C12.9453 6.06753 13.0765 6 13.2163 6C13.5118 6 13.7205 6.28951 13.627 6.56984L12.317 10.5H15.9463C16.491 10.5 17.0133 10.7164 17.3984 11.1015C18.0235 11.7265 18.1784 12.6814 17.7831 13.472L15.8941 17.25H9.60751V10.7404ZM8.10751 17.25H6.60748V11.25H8.10751V17.25Z"/>
                                    </svg>
                                </div>
                                <button onclick="likePhoto(<?php echo $photoId; ?>)" class="bg-black text-white p-2 rounded-xl max-[41px] grow-0 hover:bg-gray-800 transition duration-300">
                                    <svg width="25px" height="25px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.0501 7.04419C15.4673 5.79254 14.5357 4.5 13.2163 4.5C12.5921 4.5 12.0062 4.80147 11.6434 5.30944L8.47155 9.75H5.85748L5.10748 10.5V18L5.85748 18.75H16.8211L19.1247 14.1428C19.8088 12.7747 19.5406 11.1224 18.4591 10.0408C17.7926 9.37439 16.8888 9 15.9463 9H14.3981L15.0501 7.04419ZM9.60751 10.7404L12.864 6.1813C12.9453 6.06753 13.0765 6 13.2163 6C13.5118 6 13.7205 6.28951 13.627 6.56984L12.317 10.5H15.9463C16.491 10.5 17.0133 10.7164 17.3984 11.1015C18.0235 11.7265 18.1784 12.6814 17.7831 13.472L15.8941 17.25H9.60751V10.7404ZM8.10751 17.25H6.60748V11.25H8.10751V17.25Z" fill="#ffffff"/>
                                    </svg>
                                </button> 
                            </div>
                            
                            <?php if ($_SESSION['username'] === $author): ?>
                                <form action="php/delete_photo.php" method="POST">
                                    <input type="hidden" name="photo_id" value="<?php echo $photoId; ?>">
                                    <button type="submit" class="bg-black text-white p-2 rounded-xl hover:bg-gray-800 transition duration-300">
                                        <svg width="25px" height="25px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M18 6L17.1991 18.0129C17.129 19.065 17.0939 19.5911 16.8667 19.99C16.6666 20.3412 16.3648 20.6235 16.0011 20.7998C15.588 21 15.0607 21 14.0062 21H9.99377C8.93927 21 8.41202 21 7.99889 20.7998C7.63517 20.6235 7.33339 20.3412 7.13332 19.99C6.90607 19.5911 6.871 19.065 6.80086 18.0129L6 6M4 6H20M16 6L15.7294 5.18807C15.4671 4.40125 15.3359 4.00784 15.0927 3.71698C14.8779 3.46013 14.6021 3.26132 14.2905 3.13878C13.9376 3 13.523 3 12.6936 3H11.3064C10.477 3 10.0624 3 9.70951 3.13878C9.39792 3.26132 9.12208 3.46013 8.90729 3.71698C8.66405 4.00784 8.53292 4.40125 8.27064 5.18807L8 6" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p class="text-sm text-gray-600 mt-2"><?php echo htmlspecialchars($description); ?></p>
                </div>
            <?php
            }
            ?>
        </div>
    </main>

</body>

</html>
