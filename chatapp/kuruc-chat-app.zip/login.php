<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dokumen</title>
    <link rel="stylesheet" href="./src/output.css">
    <script src="./src/js/login.js" defer></script>
</head>
<body class="flex w-full min-h-screen object-cover object-center object-norepeat" style="background-image: url(./public/login.jpg)">
    <form 
        id="login"
        class="flex gap-3 p-8 border-[1px] border-white m-auto max-w-[1300px] w-[80%] min-w-[250px] rounded-3xl backdrop-blur-[20px]" 
        style="background-image: linear-gradient(150deg, #ffffff00, #ffffff61, #ffffffa4, #ffffffa5, #ffffffda, #ffffff, #ffffff, #ffffff, #ffffff, #ffffff);" 
        method="post">
        <div class="flex-1">
            <h1 class="font-medium pt-5">Welcome back!</h1>
        </div>

        <div class="my-auto h-[300px] grow-0 shrink-0 w-[1px] min-w-[1px] bg-black opacity-[8%]"></div>

        <div class="flex flex-col flex-1 gap-4 px-5">
            <h1 class="text-[3em] text-center pb-7 pt-5 font-medium">Log In</h1>

            <input id="username" name="username" type="text" placeholder="Username" required class="bg-[#f4f4f4] placeholder:text-zinc-400 font-light text-[1.3em] p-[10px] px-5 rounded-xl">
            <input id="password" name="password" type="password" placeholder="Password" required class="bg-[#f4f4f4] placeholder:text-zinc-400 font-light text-[1.3em] p-[10px] px-5 rounded-xl">
            <button id="signin" class="bg-black text-white  w-full text-center py-4 mt-10 rounded-xl   hover:scale-[1.02] hover:opacity-80 transition-all duration-300 ease-in-out">Log In</button>
            <p id="message" class="text-red-500"></p>

            <p class="pt-5 pb-5 opacity-[70%] text-[1.05em]">Don't have an account? <a class="underline" href="./register.php">Register</a></p>
        </div>
    </form>
</body>
<style>

    h1 {
        font-size: clamp(1.2em, 5vw, 3em);
    }
</style>
</html>