<?php
require('./db.php');

$query = "SELECT * FROM photos ORDER BY created_at DESC";
$result = $connect->query($query);

while ($row = $result->fetch_assoc()) {
    $photoId = $row['id'];
    $author = $row['author'];
    $description = $row['description'];
    $imagePath = $row['image_path'];

    $likeQuery = "SELECT COUNT(*) as likes FROM photo_likes WHERE photo_id = ?";
    $stmt = $connect->prepare($likeQuery);
    $stmt->bind_param("i", $photoId);
    $stmt->execute();
    $likeResult = $stmt->get_result();
    $likes = $likeResult->fetch_assoc()['likes'];

    echo "
    <div class='bg-white p-4 rounded-xl shadow-md'>
        <img src='$imagePath' alt='Photo' class='w-full h-64 object-cover mb-4 rounded'>
        <p class='text-sm text-gray-500 mb-2'>$author</p>
        <p class='text-lg font-semibold mb-2'>$description</p>
        <p class='text-sm text-gray-400'>Likes: $likes</p>
        <form action='like_photo.php' method='POST'>
            <input type='hidden' name='photo_id' value='$photoId'>
            <button type='submit' class='mt-2 bg-black   px-4 py-2 rounded-xl hover:bg-black transition'>Like</button>
        </form>
    </div>
    ";
}
?>
