<?php
require('./db.php');
header("Content-Type: application/json");

$input = json_decode(file_get_contents('php://input'), true);

$group_chat_id = $input['group_chat_id'];
$nickname = $input['nickname'];

$checkQuery = "SELECT * FROM group_chat_member WHERE group_chat_id = ? AND nickname = ?";
$stmt = $connect->prepare($checkQuery);
$stmt->bind_param('is', $group_chat_id, $nickname);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['error' => 'User is already a member of the group']);
    exit;
}

$addMemberQuery = "INSERT INTO group_chat_member (group_chat_id, nickname) VALUES (?, ?)";
$stmt = $connect->prepare($addMemberQuery);
$stmt->bind_param('is', $group_chat_id, $nickname);
if ($stmt->execute()) {
    echo json_encode(['success' => 'Member added successfully']);
} else {
    echo json_encode(['error' => 'Error adding member']);
}
