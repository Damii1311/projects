<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");

$myNick = $_POST['myNick'];
$friendNick = $_POST['nickname'];

$sqlCheck = "SELECT * FROM `friend_requests` WHERE `sender` = ? AND `receiver` = ?";
$stmtCheck = $connect->prepare($sqlCheck);
$stmtCheck->bind_param("ss", $myNick, $friendNick);
$stmtCheck->execute();
$result = $stmtCheck->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Friend request already sent."]);
    exit();
}

$sql = "INSERT INTO `friend_requests` (`sender`, `receiver`) VALUES (?, ?)";
$stmt = $connect->prepare($sql);
$stmt->bind_param("ss", $myNick, $friendNick);
if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Friend request sent."]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to send friend request."]);
}
?>
