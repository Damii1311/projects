<?php
session_start();
require('./db.php'); 

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$userNickname = $_SESSION['username'];
$photoId = $_POST['photo_id'];

$checkQuery = "SELECT * FROM photo_likes WHERE photo_id = ? AND user_nickname = ?";
$stmt = $connect->prepare($checkQuery);
$stmt->bind_param("is", $photoId, $userNickname);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $insertQuery = "INSERT INTO photo_likes (photo_id, user_nickname) VALUES (?, ?)";
    $stmt = $connect->prepare($insertQuery);
    $stmt->bind_param("is", $photoId, $userNickname);
    
    if ($stmt->execute()) {
        header("Location: ../gallery.php");
        exit();
    } else {
        echo "Error liking photo.";
        exit();
    }
} else {
    echo "You already liked this photo!";
    exit();
}
?>
