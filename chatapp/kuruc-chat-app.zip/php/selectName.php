<?php
// require("./db.php");
// session_start();
// header("Content-Type: application/json");

// $name=array(); 
// $chat_id=$_SESSION['chat_id'];
// $nickname1=$_SESSION['username'];
// $userData=[];
// $sql = "SELECT senderNick FROM message WHERE chat_id = $chat_id";
// $selectDatabase = $connect->query($sql);
// while ($data = $selectDatabase->fetch_assoc()) {
//     $response[] = $data; 
// }

// $response['logedNick']=$nickname1;  
// sendResponse();
// function sendResponse(){
//     global $response;
//     echo json_encode($response, JSON_PRETTY_PRINT);
//     exit();
// }