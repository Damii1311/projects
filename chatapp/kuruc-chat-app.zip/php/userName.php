<?php
require("./functions.php");
session_start();

$response['logedName']=$_SESSION['username'];

sendResponse();
