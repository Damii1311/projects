<?php
require("./db.php");

session_start();
header("Content-Type: application/json");

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

$chat_id = $_SESSION['chat_id'];
$nickname1 = $_SESSION['username'];

$sql = "SELECT * FROM message WHERE chat_id = $chat_id";
$selectDatabase = $connect->query($sql);
$response = [];
$lastMessageId = 0;

while ($data = $selectDatabase->fetch_assoc()) {
    if ($data['senderNick'] !== $nickname1) {
        $data['notMine'] = true; 
    } else {
        $data['notMine'] = false;
    }
    $response[] = $data; 
    $lastMessageId = $data['message_id']; 
}
$_SESSION['lastMessageId'] = $lastMessageId;

echo json_encode($response, JSON_PRETTY_PRINT);
exit();