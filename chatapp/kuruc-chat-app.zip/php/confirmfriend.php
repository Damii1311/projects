<?php
require('./db.php');
session_start();

$sender = $_POST['sender'];
$receiver = $_POST['receiver'];


$query = "UPDATE friend_requests SET status = 'confirmed' WHERE sender = ? AND receiver = ?";
$stmt = $connect->prepare($query);
$stmt->bind_param('ss', $sender, $receiver);
$stmt->execute();

$query = "UPDATE chat SET isActive = 1 WHERE nickname1 = ? AND nickname2 = ?;";
$stmt = $connect->prepare($query);
$stmt->bind_param('ss', $sender, $receiver);
$stmt->execute();

$query = "INSERT INTO friends (user1, user2) VALUES (?, ?), (?, ?)";
$stmt = $connect->prepare($query);
$stmt->bind_param('ssss', $sender, $receiver, $receiver, $sender);
$stmt->execute();

$query = "DELETE FROM friend_requests WHERE sender = ? AND receiver = ?";
$stmt = $connect->prepare($query);
$stmt->bind_param('ss', $sender, $receiver);
$stmt->execute();

header('Location: ../chat.php'); 
?>
