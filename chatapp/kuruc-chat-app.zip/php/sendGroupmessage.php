<?php
session_start();
require('./db.php');
header("Content-Type: application/json");

$userNickname = $_SESSION['username'];
$input = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($input['message']) && isset($input['group_chat_id'])) {
        $groupChatId = $input['group_chat_id'];
        $message = $input['message'];
    // echo json_encode([$groupChatId, $message, $_SERVER['REQUEST_METHOD']], JSON_PRETTY_PRINT);
    
    // Insert the new message into the database
    $insertMessage = "INSERT INTO group_chat_message (group_chat_id, user_id, message_text) 
                      VALUES (?, ?, ?);";
    $stmt = $connect->prepare($insertMessage);
    $stmt->bind_param('iss', $groupChatId, $userNickname, $message);
    $stmt->execute();

    echo json_encode([$groupChatId, $userNickname, $message], JSON_PRETTY_PRINT);
}
// // exit();
// ?>
