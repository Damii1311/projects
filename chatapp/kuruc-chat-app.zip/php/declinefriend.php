<?php
require('./db.php');
session_start();

$sender = $_POST['sender'];
$receiver = $_POST['receiver'];

$query = "DELETE FROM friend_requests WHERE sender = ? AND receiver = ?";
$stmt = $connect->prepare($query);
$stmt->bind_param('ss', $sender, $receiver);
$stmt->execute();

header('Location: ../chat.php'); 
?>
