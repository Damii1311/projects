<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");

$response = [];
$nickname1=$_POST['nickname'];

$_SESSION['friendUsername']=$nickname1;
$response['nickname'] = $_POST['nickname'];
$response['myNick'] = $_POST['myNick'];
$nickname2=$_SESSION['username'];
$currentDate = date('Y-m-d H:i:s');

$select = "SELECT nickname1, nickname2, chat_id FROM chat WHERE (nickname1 = '$nickname1' AND nickname2 = '$nickname2') 
   OR (nickname1 = '$nickname2' AND nickname2 = '$nickname1');";

$selectCheck=$connect->query($select);
while ($data = $selectCheck->fetch_assoc()) {
    $userData[] = $data; 
}
$_SESSION['chat_id']=$userData[0]['chat_id'];
$row=$selectCheck->num_rows;
if ($row>=1) {
    $response['error']='this chat already exist';
    sendResponse();
}


$sql = "INSERT INTO chat (`nickname1`, `nickname2`, `open_at`) VALUES ('$nickname1','$nickname2', '$currentDate')";
$intoDatabase=$connect->query($sql);
if ($intoDatabase->my_rows>0) {
    $response['error']='chat with user already exist';
    sendResponse();
}

sendResponse();
