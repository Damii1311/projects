<?php
require("./db.php");

session_start();
header("Content-Type: application/json");

$name = array();
$response = array();

$input = json_decode(file_get_contents('php://input'), true);

$inputName = $input['searchName'];
$currentUser = $_SESSION['username'];

$sql = "SELECT `nickname`, `avatar_url` FROM `user` WHERE `nickname` LIKE '%$inputName%' LIMIT 10;";
$intoDatabase = $connect->query($sql);

while ($result = $intoDatabase->fetch_assoc()) {
    $name[] = $result;
}

if (empty($name)) {
    $response['error'] = 'nick doesnt exist';
    sendResponse($response);
}

foreach ($name as &$user) {
    $nickname = $user['nickname'];
    
    $checkFriendship = "SELECT * FROM `friend_requests` WHERE 
        (`sender` = '$currentUser' AND `receiver` = '$nickname' AND `status` = 'confirmed') 
        OR 
        (`sender` = '$nickname' AND `receiver` = '$currentUser' AND `status` = 'confirmed');";
    
    $result = $connect->query($checkFriendship);

    if ($result->num_rows > 0) {
        $user['action'] = 'Chat';
    } else {
        $user['action'] = 'Add Friend';
    }
}

$response['sessionName'] = $_SESSION['username'];
$response["users"] = $name; // Pridanie aktuálneho používateľa do odpovede
// sendResponse($response);
// exit();

echo json_encode($response, JSON_PRETTY_PRINT);
exit();