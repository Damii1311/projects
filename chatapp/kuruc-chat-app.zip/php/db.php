<?php

$servername = getenv('DB_HOST') ?: 'localhost';
$username = getenv('DB_USER') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';
$dbname = getenv('DB_NAME') ?: 'kuruc2024';
$connect = new mysqli($servername,$username,$password,$dbname);

if ($connect->connect_error) die("Connection failed: " . $connect->connect_error);