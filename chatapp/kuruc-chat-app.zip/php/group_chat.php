<?php
session_start();
require('./db.php');

header("Content-Type: application/json");


$action = $_GET['action'] ?? $_POST['action'] ?? null;
$response = [];

if (!$action) {
    $response['error'] = "No action specified.";
    echo json_encode($response);
    exit;
}


switch ($action) {

   
    case 'fetchMessages':
        $group_chat_id = $_GET['group_chat_id'] ?? null;

        if (!$group_chat_id) {
            $response['error'] = "Group chat ID is required.";
            break;
        }

        $query = "SELECT gcm.message_id, gcm.message_text, gcm.sent_at, gcm.user_id
                  FROM group_chat_messages gcm
                  WHERE gcm.group_chat_id = ?
                  ORDER BY gcm.sent_at ASC";
        $stmt = $connect->prepare($query);
        $stmt->bind_param('i', $group_chat_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }

        $response['success'] = true;
        $response['messages'] = $messages;
        break;

    // Send a message
    case 'sendMessage':
        $group_chat_id = $_POST['group_chat_id'] ?? null;
        $message = $_POST['message'] ?? null;
        $user_id = $_SESSION['username'];

        if (!$group_chat_id || !$message) {
            $response['error'] = "Group chat ID and message text are required.";
            break;
        }

        $query = "INSERT INTO group_chat_messages (group_chat_id, user_id, message_text, sent_at)
                  VALUES (?, ?, ?, NOW())";
        $stmt = $connect->prepare($query);
        $stmt->bind_param('iss', $group_chat_id, $user_id, $message);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $response['success'] = "Message sent successfully.";
        } else {
            $response['error'] = "Failed to send message.";
        }
        break;

    case 'addMember':
        $group_chat_id = $_POST['group_chat_id'] ?? null;
        $nickname = $_POST['nickname'] ?? null;

        if (!$group_chat_id || !$nickname) {
            $response['error'] = "Group chat ID and nickname are required.";
            break;
        }

       
        $checkQuery = "SELECT * FROM group_chat_member WHERE group_chat_id = ? AND nickname = ?";
        $stmt = $connect->prepare($checkQuery);
        $stmt->bind_param('is', $group_chat_id, $nickname);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response['error'] = "User is already a member of the group.";
            break;
        }

        
        $insertQuery = "INSERT INTO group_chat_member (group_chat_id, nickname, joined_at)
                        VALUES (?, ?, NOW())";
        $stmt = $connect->prepare($insertQuery);
        $stmt->bind_param('is', $group_chat_id, $nickname);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $response['success'] = "Member added successfully.";
        } else {
            $response['error'] = "Failed to add member.";
        }
        break;

    default:
        $response['error'] = "Invalid action specified.";
        break;
}

echo json_encode($response);
exit;
