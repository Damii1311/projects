<?php
session_start();
require('./db.php'); 
header("Content-Type: application/json");

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['group_chat_id'])) {
    $groupChatId = $input['group_chat_id'];
    $fetchMessages = "SELECT * FROM group_chat_message WHERE group_chat_id = ? ORDER BY sent_at ASC";
    $stmt = $connect->prepare($fetchMessages);
    $stmt->bind_param('i', $groupChatId);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    echo json_encode($messages, JSON_PRETTY_PRINT);
} else {
    echo json_encode(['error' => 'group_chat_id not set']);
}
exit();
?>
