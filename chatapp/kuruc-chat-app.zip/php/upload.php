<?php
session_start();
require('./db.php'); 

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$userNickname = $_SESSION['username'];
$description = $_POST['description'];
$image = $_FILES['photo'];

if (empty($image['name'])) {
    echo "Please select an image to upload.";
    exit();
}

$imageName = time() . '-' . basename($image['name']);
$targetDir = '../public/uploads/'; 
$targetFile = $targetDir . $imageName;

if (getimagesize($image['tmp_name']) === false) {
    echo "Only image files are allowed.";
    exit();
}

if ($image['size'] > 5000000) { 
    echo "File is too large.";
    exit();
}

if (!move_uploaded_file($image['tmp_name'], $targetFile)) {
    echo "Error uploading image.";
    exit();
}

$stmt = $connect->prepare("INSERT INTO photos (author, description, image_path) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $userNickname, $description, $targetFile);
if ($stmt->execute()) {
    header("Location: ../index.php"); 
    exit();
} else {
    echo "Error saving image details to the database.";
}
?>
