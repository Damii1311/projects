<?php
session_start();
require('./db.php'); 

if (!isset($_SESSION['username'])) {
    echo "You must be logged in to delete a photo.";
    exit();
}

if (isset($_POST['photo_id'])) {
    $photoId = $_POST['photo_id'];
    $username = $_SESSION['username'];

    $query = "SELECT author, image_path FROM photos WHERE id = ?";
    $stmt = $connect->prepare($query);
    $stmt->bind_param("i", $photoId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $photo = $result->fetch_assoc();
        $author = $photo['author'];
        $imagePath = $photo['image_path'];

        if ($author === $username) {
            $deleteLikesQuery = "DELETE FROM photo_likes WHERE photo_id = ?";
            $stmt = $connect->prepare($deleteLikesQuery);
            $stmt->bind_param("i", $photoId);
            $stmt->execute();

            $deleteQuery = "DELETE FROM photos WHERE id = ?";
            $stmt = $connect->prepare($deleteQuery);
            $stmt->bind_param("i", $photoId);
            $stmt->execute();

            if (file_exists($imagePath)) {
                unlink($imagePath); 
            }

            header("Location: ../index.php");
                } else {
            echo "You are not authorized to delete this photo.";
        }
    } else {
        echo "Photo not found.";
    }
} else {
    echo "No photo ID provided.";
}
?>
