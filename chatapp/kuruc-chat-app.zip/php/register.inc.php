<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");
$input = json_decode(file_get_contents("php://input"), true);

$response = array(); 

$username= $input["username"];
$password= $input["password"];

if (strlen($username) > 20 && strlen($username) < 4) {
    $response['message'] = 'invalid username length';
    $response['code']='500';
    sendResponse();
}

if (strlen($password) < 5) {
    $response['message'] = 'password too short';
    $response['code']='500';
    sendResponse();
}

$stmt = $connect->prepare("SELECT * FROM user WHERE nickname = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $response['message'] = "The name is already taken.";
    $response['code'] = "500";
    sendResponse();
}


$hashPassword= password_hash($password, PASSWORD_DEFAULT);
$profile_url = "./public/profile.jpg";

$stmt = $connect->prepare("INSERT INTO user (`nickname`, `Password`, `avatar_url`) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $hashPassword, $profile_url);

$intoDatabase = $stmt->execute();

if (!$intoDatabase) {
    $response['error']="The user and password wasn't inserted into database";
    $response['message']="The error occured on the server.";
    sendResponse();
}

$_SESSION['username'] = $username;
$_SESSION['avatar_url'] = "./public/profile.jpg";

$response['code']='200';
$response['message']="user was succesfully registered";
$response['username']=$username;

sendResponse();
$stmt->close();