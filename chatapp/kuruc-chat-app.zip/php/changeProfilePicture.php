<?php
session_start();
require('./db.php'); 

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$userNickname = $_SESSION['username'];
$image = $_FILES['profile_picture'];

if (empty($image['name'])) {
    echo "Please select an image to upload.";
    exit();
}

$imageName = time() . '-' . basename($image['name']);
$targetDir = '../public/avatars/' . $imageName; 

if (getimagesize($image['tmp_name']) === false) {
    echo "Only image files are allowed.";
    exit();
}

if ($image['size'] > 5000000) { 
    echo "File is too large.";
    exit();
}

if (!move_uploaded_file($image['tmp_name'], $targetDir)) {
    echo "Error uploading image.";
    exit();
}

$stmt = $connect->prepare("UPDATE user SET avatar_url = ? WHERE nickname = ?");
$stmt->bind_param("ss", $targetDir, $userNickname);
$stmt->execute();

$_SESSION['avatar_url'] = $targetDir;

header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>
