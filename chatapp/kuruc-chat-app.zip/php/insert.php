<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");

$message = $_POST['input'];
$nickname1 = $_SESSION['username'];
$nickname2 = $_SESSION['friendUsername'];

$select = "SELECT * FROM chat WHERE (nickname1 = '$nickname1' AND nickname2 = '$nickname2') 
OR (nickname1 = '$nickname2' AND nickname2 = '$nickname1');";
$selectDatabase = $connect->query($select);

if ($selectDatabase->num_rows > 0) {
    $userData = $selectDatabase->fetch_assoc();
    $chat_id = $userData['chat_id'];
    $_SESSION['chat_id'] = $chat_id;
    
    $sql = "INSERT INTO message (`chat_id`, `message_content`, `senderNick`) VALUES('$chat_id', '$message', '$nickname1')";

    if(strlen($message) > 0) {
        $intodatabase = $connect->query($sql);
    }

    if (!$intodatabase) {
        $response['error'] = 'There was an error inserting the message.';
    } else {
        $response['name'] = $nickname1; 
        $response['chatId'] = $chat_id; 
        $response['message'] = $message; 
    }
} else {
    $response['error'] = 'Chat does not exist.';
}

sendResponse($response);

