<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");
$name=array(); 
$chat_id=$_SESSION['chat_id'];
$nickname1=$_SESSION['username'];
$lastMessageId= $_SESSION['lastMessageId'];


$sql = "SELECT * FROM message WHERE chat_id = $chat_id AND message_id>$lastMessageId";
$selectDatabase = $connect->query($sql);


while ($data = $selectDatabase->fetch_assoc()) {
    
    
    if ($data['senderNick']!==$nickname1)
    {
        $data['notMine']=true;
    } 
    $response[] = $data; 
    $lastMessageId = $data['message_id'];
}
$_SESSION['lastMessageId']=$lastMessageId;

sendResponse();

