<?php
require("./db.php");
session_start();

$user = $_SESSION['username'];

$sql = "SELECT * FROM `friend_requests` WHERE `receiver` = ? AND `status` = 0";
$stmt = $connect->prepare($sql);
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

$requests = [];
while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}

echo json_encode($requests);
?>
