<?php
require("./functions.php");

session_start();

$_SESSION = NULL;
session_destroy();

$response['message']='logout succesfull';
sendResponse();
header("Location: ../login.php");
exit();

