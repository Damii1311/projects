<?php
require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");
$input = json_decode(file_get_contents("php://input"), true);

$response = array(); 

$username= $input["username"];
$password= $input["password"];

$_SESSION['username'] = $username;

// $sql= "SELECT * FROM user WHERE nickname='$username'";
// $intoDatabase=$connect->query($sql);

$stmt = $connect->prepare("SELECT * FROM user WHERE nickname=?");
$stmt->bind_param("s", $username);

$intoDatabase = $stmt->execute();

if (!$intoDatabase) {
    $response['message']="Error occurred on server.";
    $response['code']="500";
    sendResponse();
}

$result = $stmt->get_result();
$userData=$result->fetch_assoc();

if($result->num_rows == 0) {
    $response['message']="Username or password is incorrect.";
    $response['code']="500";
    sendResponse();
}else {
    if ($username == $userData['nickname']) {
        if (password_verify($password,$userData['password'])==$userData['password']) {
            $_SESSION["avatar_url"] = $userData['avatar_url'];
            $response['code']="200";
            $response['message']="Login was succesful";
        }else {
            $response['message']="Username or password is incorrect.";
            $response['code']="500";
        }
    }else {
        $response['message']="Username or password is incorrect.";
        $response['code']="500";
    }
}

sendResponse();
$stmt->close();

