<?php
require("./db.php");
session_start();

$myNick = $_POST['myNick'];
$nickname = $_POST['nickname'];

$sql = "SELECT * FROM `friends` WHERE (`user1` = ? AND `user2` = ?) OR (`user1` = ? AND `user2` = ?)";
$stmt = $connect->prepare($sql);
$stmt->bind_param("ssss", $myNick, $nickname, $nickname, $myNick);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["isFriend" => true]);
} else {
    echo json_encode(["isFriend" => false]);
}
?>
