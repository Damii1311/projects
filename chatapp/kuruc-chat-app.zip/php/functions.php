<?php

function sendResponse(){
    global $response;
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit();
}