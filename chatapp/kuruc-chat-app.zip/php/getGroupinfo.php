<?php

require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");

$response = [];

$group_chat_id = $_POST['group_chat_id'];  


function sendResponse($response) {
    echo json_encode($response);
    exit;
}


$selectGroup = "SELECT chat_name, created_at FROM group_chat WHERE group_chat_id = ?";
$stmt = $connect->prepare($selectGroup);
$stmt->bind_param('i', $group_chat_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows == 0) {
    $response['error'] = 'Group chat not found';
    sendResponse($response);
}

$stmt->bind_result($chat_name, $created_at);
$stmt->fetch();

$response['chat_name'] = $chat_name;
$response['created_at'] = $created_at;

$selectMembers = "SELECT nickname, joined_at FROM group_chat_member WHERE group_chat_id = ?";
$stmt = $connect->prepare($selectMembers);
$stmt->bind_param('i', $group_chat_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($member_nickname, $joined_at);

$members = [];
while ($stmt->fetch()) {
    $members[] = ['nickname' => $member_nickname, 'joined_at' => $joined_at];
}

$response['members'] = $members;

sendResponse($response);
