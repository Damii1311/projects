<?php
require("./db.php");

session_start();
header("Content-Type: application/json");

$response = [];

$chatName = $_POST['chat_name']; 
$nickname = $_SESSION['username'];

function sendResponse($response) {
    echo json_encode($response);
    exit;
}

$select = "SELECT group_chat_id FROM group_chat WHERE chat_name = ?";
$stmt = $connect->prepare($select);
$stmt->bind_param('s', $chatName);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $response['error'] = 'Group chat with this name already exists';
    sendResponse($response);
}

$insertChat = "INSERT INTO group_chat (chat_name) VALUES (?)";
$stmt = $connect->prepare($insertChat);
$stmt->bind_param('s', $chatName);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    $group_chat_id = $stmt->insert_id;  

    $insertMember = "INSERT INTO group_chat_member (group_chat_id, nickname) VALUES (?, ?)";
    $stmt = $connect->prepare($insertMember);
    $stmt->bind_param('is', $group_chat_id, $nickname);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $response['success'] = 'Group chat created successfully and you are added as the first member';
        $response['group_chat_id'] = $group_chat_id;
    } else {
        $response['error'] = 'Error adding user to the group chat';
    }
} else {
    $response['error'] = 'Error creating group chat';
}

sendResponse($response);
