<?php

require("./db.php");
require("./functions.php");

session_start();
header("Content-Type: application/json");

$name = array();
$response = array();
$nickname1 = $_SESSION['username'];


$sql = "
    SELECT nickname1, nickname2, open_at 
    FROM chat 
    WHERE (nickname1 = '$nickname1' OR nickname2 = '$nickname1') AND isActive = 1
        ORDER BY open_at ASC 
    LIMIT 6;
";

$intoDatabase = $connect->query($sql);

while ($result = $intoDatabase->fetch_assoc()) {
    if ($result['nickname1'] === $nickname1) {
        $name[] = $result['nickname2'];  
    } else {
        $name[] = $result['nickname1'];  
    }
}


$usersDetails = array();
if (!empty($name)) {
    $namePlaceholders = implode(',', array_fill(0, count($name), '?')); // Prepare placeholders for SQL
    $stmt = $connect->prepare("
        SELECT `nickname`, `avatar_url` 
        FROM `user` 
        WHERE `nickname` IN ($namePlaceholders) 
        LIMIT 10;
    ");

   
    $stmt->bind_param(str_repeat('s', count($name)), ...$name);

    $stmt->execute();
    $result = $stmt->get_result();

    while ($user = $result->fetch_assoc()) {
        $usersDetails[] = $user;
    }

    $stmt->close();
}


$response["users"] = $usersDetails;
echo json_encode($response, JSON_PRETTY_PRINT);
exit();
?>
