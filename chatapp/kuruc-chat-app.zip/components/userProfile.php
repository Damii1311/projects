<div class="header flex items-center justify-between p-5">
    <div class="nameImg flex items-center space-x-4">
        <form action="./php/changeProfilePicture.php" method="POST" class="cursor-pointer" enctype="multipart/form-data">
            <input type="file" name="profile_picture" id="profile_picture" class="hidden cursor-pointer" onchange="this.form.submit()">
            <button type="submit">
                <img src="<?php echo $_SESSION["avatar_url"] ? $_SESSION["avatar_url"] : "./public/profile.jpg" ?>" alt="" class="w-14 h-14 rounded-full object-cover">
            </button>
        </form>
        <div class="name">
            <p class="nickname font-semibold text-lg"><?php echo $userNickname; ?></p>
            <p class="status text-sm text-gray-400">Online</p>
        </div>
    </div>
</div>

<script>
    document.querySelector('button[type="submit"]').addEventListener('click', function(event) {
        event.preventDefault();
        document.getElementById('profile_picture').click();
    });
</script>
