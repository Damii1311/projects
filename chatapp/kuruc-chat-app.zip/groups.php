<?php
session_start();
require('./php/db.php'); 

$userNickname = $_SESSION['username']; 

$query = "SELECT gcm.id AS group_chat_member_id, gc.chat_name, gc.group_chat_id
          FROM group_chat_member gcm
          JOIN group_chat gc ON gcm.group_chat_id = gc.group_chat_id
          WHERE gcm.nickname = ?";
$stmt = $connect->prepare($query);
$stmt->bind_param('s', $userNickname);
$stmt->execute();
$result = $stmt->get_result();
$groups = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_group'])) {
    global $groupChatId;

    $groupName = $_POST['group_name'];
    
    $insertGroup = "INSERT INTO group_chat (chat_name) VALUES (?)";
    $stmt = $connect->prepare($insertGroup);
    $stmt->bind_param('s', $groupName);
    $stmt->execute();
    
    $groupChatId = $stmt->insert_id;

   
    $insertMember = "INSERT INTO group_chat_member (group_chat_id, nickname) VALUES (?, ?)";
    $stmt = $connect->prepare($insertMember);
    $stmt->bind_param('is', $groupChatId, $userNickname);
    $stmt->execute();
    
    header("Location: groups.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groups</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="min-h-screen flex w-full h-full bg-white">
    <?php include("./components/header.php") ?>

    <main class="wrapper shadow-2xl overflow-hidden flex w-full">
        <div class="container max-w-sm w-3/4 border-r border-gray-200">
            <?php include("./components/userProfile.php") ?>

            <form action="groups.php" method="POST" class="p-4">
                <input type="text" name="group_name" placeholder="Enter group name" class="w-full px-4 py-3 mb-3 rounded-xl border border-gray-300" required>
                <button type="submit" name="create_group" class="w-full bg-black text-white py-3 rounded-xl">Create Group</button>
            </form>

            <div id="groups" class="inbox p-5 space-y-4 overflow-y-auto max-h-[50vh]">
                <h3 class="text-sm text-gray-700">Groups</h3>
                <ul class="flex flex-col gap-2">
                    <?php foreach ($groups as $group): ?>
                        <li class="flex justify-between items-center p-3 rounded-xl hover:bg-gray-100 cursor-pointer"
                            onclick="loadGroupChat(<?php echo $group['group_chat_id']; ?>, '<?php echo $group['chat_name']; ?>')">
                            <p class="truncate text-[16px] font-semibold"><?php echo htmlspecialchars($group['chat_name']); ?></p>
                        </li>
                    <?php endforeach; ?>
                    <?php if (count($groups) === 0): ?>
                        <li class="text-gray-400">No groups yet.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
      
        <div class="container chat-container w-full flex flex-col">
            <div class="flex justify-between header p-4 border-b border-gray-200 bg-gray-100" id="group-header">
                <div id="activegroup" class="justify-between w-full " style="display: none;">
                    <h2 id="groupName"></h2>
                    <div class="flex gap-2">
                        <input id="addUsername" type="text" name="addUsername" placeholder="Enter user's nickname" class="w-full px-3 py-2 rounded-xl border border-gray-300" style="max-width: 150px;">
                        <button id="addUser" type="button" class="bg-black rounded-xl px-4 py-1 text-white">Add user</button>
                    </div>
                </div>
                
                <h2 id="selecttitle" class="text-lg font-semibold">Select a group to chat</h2>
            </div>
            <div class="main flex flex-col gap-2 flex-1 overflow-y-auto p-6" id="messageBody">
               
            </div>
            <form id="chat-form" method="POST">
                <div class="search flex items-center border-t border-gray-200 p-6">
                    <input id="input" name="message" type="text" placeholder="Type your message here" class="message-input flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-black" disabled>
                    
                    <button id="send-btn" class="searchBtn bg-black p-3 rounded-xl ml-3 hover:bg-black transition" disabled>
                        <svg fill="#ffffff" width="25px" height="25px" viewBox="0 0 56 56" xmlns="http://www.w3.org/2000/svg"><path d="M 32.7812 52.5508 C 34.4687 52.5508 35.6640 51.0977 36.5312 48.8477 L 51.8829 8.7461 C 52.3048 7.6679 52.5626 6.7070 52.5626 5.9101 C 52.5626 4.3867 51.6016 3.4492 50.0781 3.4492 C 49.2813 3.4492 48.3203 3.6836 47.2423 4.1055 L 6.9296 19.5508 C 4.9609 20.3008 3.4374 21.4961 3.4374 23.2070 C 3.4374 25.3633 5.0780 26.0898 7.3280 26.7695 L 24.2499 31.7383 L 29.1718 48.4492 C 29.8749 50.8164 30.6015 52.5508 32.7812 52.5508 Z M 25.3046 28.1758 L 9.1328 23.2305 C 8.7577 23.1133 8.6406 23.0195 8.6406 22.8555 C 8.6406 22.6914 8.7343 22.5742 9.0859 22.4336 L 40.7733 10.4336 C 42.6484 9.7305 44.4531 8.7930 46.1874 7.9961 C 44.6406 9.2617 42.7187 10.7617 41.4296 12.0508 Z M 33.1562 47.3945 C 32.9687 47.3945 32.8749 47.2305 32.7577 46.8555 L 27.8124 30.6836 L 43.9374 14.5586 C 45.2031 13.2930 46.7733 11.3242 48.0155 9.7305 C 47.2187 11.5117 46.2812 13.3164 45.5546 15.2148 L 33.5546 46.9023 C 33.4140 47.2539 33.3202 47.3945 33.1562 47.3945 Z"/></svg>
                    </button>
                </div>
            </form>
        </div>
    </main>

    <script>
        let activeGroupId = null;

        
        function loadGroupChat(groupId, groupName) {
            activeGroupId = groupId;
            document.querySelector('#activegroup').style.display = "flex"
            document.querySelector('#selecttitle').style.display = "none"

            document.getElementById('input').disabled = false;
            document.getElementById('send-btn').disabled = false;
            
            fetchMessages(groupId);
        }
        
       
        async function fetchMessages(groupId) {
            await fetch(`./php/fetchGroupMessages.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    group_chat_id: groupId
                })
            }).then(res => res.json()).then(data => {
                const messageBody = document.getElementById('messageBody');
                messageBody.innerHTML = '';
                data.forEach(msg => {
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message';
                    msgDiv.innerHTML = `<p><strong>${msg.user_id}:</strong> ${msg.message_text}</p><small>${msg.sent_at}</small>`;
                    messageBody.appendChild(msgDiv);
                });
            }).catch(err => {
                console.log(err)
            });
        }

        document.getElementById('chat-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const message = document.getElementById('input').value;
            if (!message.trim()) return;

            fetch('./php/sendGroupmessage.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: message,
                    group_chat_id: activeGroupId
                })
            }).then(res => res.json()).then(data => {
                document.getElementById('input').value = '';
                console.log(data);
                // fetchMessages(activeGroupId);
            }).catch(err => {
                console.log(err)
            });
        });

        document.getElementById('addUser').addEventListener('click', (e) => {
            e.preventDefault();
            const username = document.getElementById('addUsername').value;

            fetch('./php/addgroupmember.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    nickname: username,
                    group_chat_id: activeGroupId
                })
            }).then(res => res.json()).then(data => {
                console.log(data);
                // document.getElementById('input').value = '';
                // fetchMessages(activeGroupId);
            })
        });

        // Auto-refresh messages
        setInterval(() => {
            if (activeGroupId) fetchMessages(activeGroupId);
        }, 3000);
    </script>
</body>
</html>
