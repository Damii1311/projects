function likePhoto(photoId) {
    fetch('php/like_photo.php', {
        method: 'POST',
        body: new URLSearchParams({
            'photo_id': photoId
        }),
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
    .then(response => response.text())
    .then(data => {
        if (data === 'You already liked this photo!') {
            alert(data); 
        } else {
            alert('Liked successfully!');
            location.reload(); 
        }
    });
}

function toggleForm() {
    const gallery = document.getElementById('gallery');
    const uploadForm = document.getElementById('uploadFormContainer');

    if (uploadForm.classList.contains('hidden')) {
        uploadForm.classList.remove('hidden');
        gallery.classList.add('hidden');
    } else {
        uploadForm.classList.add('hidden');
        gallery.classList.remove('hidden');
    }
}
