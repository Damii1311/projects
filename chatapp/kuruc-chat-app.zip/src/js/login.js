console.log("login.js loaded");


document.querySelector("#login").addEventListener("submit", e => {
    e.preventDefault();

    fetch("./php/login.inc.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username: document.querySelector("#username").value,
            password: document.querySelector("#password").value
        })
    }).then(res => res.json())
    .then(data => {
        console.log(data);
        document.querySelector("#message").innerHTML = data.message;
        if(data.code === "200") window.location.href = "/index.php";
    }).catch(err => {
        console.log(err);
    });
});

