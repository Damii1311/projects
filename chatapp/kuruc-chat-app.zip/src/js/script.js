let form = document.querySelector("form"); 
let searchUsers = document.querySelector("#search"); 
let error = document.querySelector('.error');
const inbox = document.querySelector('#inbox');
const myNick = document.querySelector('.nickname');

fetch('./php/userName.php')
    .then(res => res.json())
    .then(data => {
        myNick.textContent = data.logedName;
});
fetch('./php/recent_chats.php')
.then(res => res.json())
.then(data => {
    for (let i = 0; i < data.users.length; i++) {
        insertUsers(data.users[i].nickname, data.users[i].avatar_url);    }
}).catch(err => console.log(err));

    function insertUsers(nickname, avatar) {
        let div = document.createElement('div');
            div.className = 'nameImg';
            div.innerHTML = `
                <li class='flex justify-between overflow-hidden'>
                    <div class="flex gap-4">
                        <img src="${avatar ? avatar : './public/profile.jpg'}" class="w-12 h-12 my-auto rounded-full object-cover" alt="User Profile">
                        <p id="nickname" class="nickname truncate capitalize text-[20px] my-auto">${nickname}</p>
                    </div>
                    <button id="btn" class="bg-black p-3 text-white rounded-xl text-sm hover:bg-opacity-80">
                        <svg width="25px" height="25px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="Page-1" stroke="none" stroke-width="0.1px" fill="none" fill-rule="evenodd">
                                <g id="Dribbble-Light-Preview" transform="translate(-60.000000, -2239.000000)" fill="#ffffff">
                                    <g id="icons" transform="translate(56.000000, 160.000000)">
                                        <path d="M24.0001371,2083 C24.0001371,2083.552 23.5521371,2084 23.0001371,2084 L21.0001371,2084 L21.0001371,2086 C21.0001371,2086.552 20.5521371,2087 20.0001371,2087 C19.4481371,2087 19.0001371,2086.552 19.0001371,2086 L19.0001371,2084 L17.0001371,2084 C16.4481371,2084 16.0001371,2083.552 16.0001371,2083 C16.0001371,2082.448 16.4481371,2082 17.0001371,2082 L19.0001371,2082 L19.0001371,2080 C19.0001371,2079.448 19.4481371,2079 20.0001371,2079 C20.5521371,2079 21.0001371,2079.448 21.0001371,2080 L21.0001371,2082 L23.0001371,2082 C23.5521371,2082 24.0001371,2082.448 24.0001371,2083 M15.7401371,2097 L7.6121371,2097 C6.8171371,2097 6.3141371,2096.099 6.7721371,2095.449 C7.8511371,2093.92 9.6251371,2092.916 11.6331371,2092.902 C11.6471371,2092.902 11.6611371,2092.906 11.6751371,2092.906 C11.6901371,2092.906 11.7031371,2092.902 11.7181371,2092.902 C13.7271371,2092.916 15.5021371,2093.919 16.5801371,2095.449 C17.0381371,2096.099 16.5361371,2097 15.7401371,2097 M11.6751371,2086.906 C12.7781371,2086.906 13.6751371,2087.803 13.6751371,2088.906 C13.6751371,2089.995 12.8001371,2090.879 11.7181371,2090.902 C11.7031371,2090.902 11.6901371,2090.9 11.6751371,2090.9 C11.6611371,2090.9 11.6471371,2090.902 11.6331371,2090.902 C10.5501371,2090.879 9.6751371,2089.995 9.6751371,2088.906 C9.6751371,2087.803 10.5731371,2086.906 11.6751371,2086.906 M14.7011371,2091.495 C15.5311371,2090.527 15.9311371,2089.18 15.5001371,2087.724 C15.1031371,2086.38 13.9731371,2085.319 12.6061371,2085.011 C9.9921371,2084.422 7.6751371,2086.393 7.6751371,2088.906 C7.6751371,2089.899 8.0501371,2090.796 8.6491371,2091.495 C6.5201371,2092.365 4.8481371,2094.181 4.1011371,2096.4 C3.6711371,2097.68 4.6691371,2099 6.0191371,2099 L17.3311371,2099 C18.6811371,2099 19.6801371,2097.68 19.2491371,2096.4 C18.5021371,2094.181 16.8311371,2092.365 14.7011371,2091.495" id="profile_plus_round-[#1324]">

                                    </path>
                                    </g>
                                </g>
                            </g>
                        </svg>
                    </button>
                </li>
            `;

        const btn = div.querySelector("#btn");

        fetch('./php/check_friend_status.php', {
            method: 'POST',
            body: new URLSearchParams({
                'nickname': nickname,
                'myNick': myNick.textContent
            })
        })
        .then(res => res.json())
        .then(friendData => {
            if (friendData.isFriend) {
                btn.setAttribute('type', "chat"); 
            } else {
                btn.setAttribute("type", "add"); 
            }
        });
        
        btn.addEventListener('click', function() {
            let nicknameData = new FormData();
            nicknameData.append('nickname', nickname);
            nicknameData.append('myNick', myNick.textContent);

            if (btn.getAttribute("type") === "add") {
                fetch('./php/addfriend.php', {
                    method: 'POST',
                    body: nicknameData
                })
                .then(res => res.json())
                .then(response => {
                    alert('Friend request sent!');
                });
            }

            if (btn.getAttribute("type") === "chat") {
                fetch('./php/chat.php', {
                    method: 'POST',
                    body:nicknameData
                })
                .then(res => res.json())
                .then(data => {
                    console.log(data);
                    // window.location.href = `./chat.php?nickname=${nickname}`;
                }).catch(err => console.log(err));
            }
        });

        inbox.appendChild(div);
}

searchUsers.addEventListener("submit", function(e) {
    e.preventDefault();

    fetch("./php/search.php", {
        method: 'POST',
        body: JSON.stringify({
            searchName: document.querySelector("#searchInput").value
        }),
    }).then(res => res.json())
    .then(data => {
        console.log(data);
        if (data.error) {
            error.textContent = 'This user doesnt exist';
            return false;
        }
        inbox.innerHTML = '';
        error.textContent = '';
        
        for(let i = 0; i < data.users.length; i++) {
            insertUsers(data.users[i].nickname, data.users[i].avatar_url);
        }
    }).catch(err => console.log(err));
});
