const logout = document.querySelector(".logout");

logout.addEventListener("click", function() {
    fetch("./php/logout.inc.php", { method: 'POST' })
    .then(data => {
        window.location.href = './login.php';
    });
});