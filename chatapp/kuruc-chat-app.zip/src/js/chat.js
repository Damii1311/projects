let formInput = document.querySelector("#input");
let main = document.querySelector('.main');
let form = document.querySelector("#formular");

function selectMessages() {
    fetch('./php/select.php')
        .then(res => res.json())
        .then(data => {
            main.innerHTML = "";

            console.log(data);
            
            data.forEach(message => {
                if(message.notMine) {
                    main.innerHTML += `<p class="bg-gray-100 px-4 py-2 mr-auto rounded-2xl">${message.message_content}</p>`;
                }else {
                    main.innerHTML += `<p class="bg-black text-white px-4 py-2 ml-auto rounded-2xl">${message.message_content}</p>`;
                }
            });
        })
        .catch(err => console.log(err));
}

selectMessages();

setInterval(selectMessages, 1000);

form.addEventListener("submit", function (e) {
    e.preventDefault(); 
    let data = new FormData(form);
    console.log(data)
    
    fetch('./php/insert.php', {
        method: 'POST',
        body: data
    })
    .then(res => res.json())
    .then(data1 => {
        console.log(data1);
        main.innerHTML += `<p class="bg-[#cfcfcf] px-3 py-1 mr-auto rounded-2xl">${data1.message}</p>`;
        formInput.value = "";
    })
    .catch(err => console.error('Error:', err)); 
});
