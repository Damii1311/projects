<?php
session_start();
require('./php/db.php');

$userNickname = $_SESSION['username'];

$query = "SELECT DISTINCT * FROM friends 
        JOIN user ON nickname = user2
        WHERE user1 = ? OR user2 = ? AND user2 != ?";
$stmt = $connect->prepare($query);
$stmt->bind_param('sss', $userNickname, $userNickname, $userNickname);
$stmt->execute();
$result = $stmt->get_result();
$friends = $result->fetch_all(MYSQLI_ASSOC);


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_friend'])) {
    $friendNickname = $_POST['friend_nickname'];

    $deleteQuery = "DELETE FROM friends WHERE (user1 = ? AND user2 = ?) OR (user1 = ? AND user2 = ?)";
    $deleteStmt = $connect->prepare($deleteQuery);
    $deleteStmt->bind_param('ssss', $userNickname, $friendNickname, $friendNickname, $userNickname);

    $updateQuery = "UPDATE chat SET isActive = 0 WHERE (nickname1 = ? AND nickname2 = ?) OR (nickname1 = ? AND nickname2 = ?)";
    $updateStmt = $connect->prepare($updateQuery);
    $updateStmt->bind_param('ssss', $userNickname, $friendNickname, $friendNickname, $userNickname);

    $deleteStmt->execute();
    $updateStmt->execute();
    echo "<script>alert('Friend was deleted successfully.');</script>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Friends</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="min-h-screen flex w-full h-full bg-white">
    <?php include("./components/header.php"); 
    ?>
    
    <main class="wrapper shadow-2xl overflow-hidden flex w-full">
        <div class="container max-w-sm w-3/4 border-r border-gray-200 p-5">
            <h2 class="text-xl font-semibold mb-4">Your Friends</h2>
            <ul class="friends-list space-y-4">
                <?php if (count($friends) > 0): ?>
                    <?php foreach ($friends as $friend): ?>
                        <li class="flex justify-between items-center p-3 rounded-xl">
                            <div class="flex gap-3">
                                <img src="<?php echo !empty($friend['avatar_url']) ? $friend['avatar_url'] : "./public/profile.jpg" ?>" class="w-12 h-12 my-auto rounded-full object-cover" alt="User Profile">
                                <p class="nickname truncate capitalize my-auto"><?php echo $friend['user1'] === $userNickname ? $friend['user2'] : $friend['user1']; ?></p>
                            </div>
                            <form method="POST" action="/friends.php">
                                <input type="hidden" name="friend_nickname" value="<?php echo $friend['user1'] === $userNickname ? $friend['user2'] : $friend['user1']; ?>">
                                <button type="submit" name="delete_friend" class="bg-black text-white p-3 rounded-xl">
                                    <svg fill="#ffffff" width="25px" height="25px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M2,21h8a1,1,0,0,0,0-2H3.071A7.011,7.011,0,0,1,10,13a5.044,5.044,0,1,0-3.377-1.337A9.01,9.01,0,0,0,1,20,1,1,0,0,0,2,21ZM10,5A3,3,0,1,1,7,8,3,3,0,0,1,10,5ZM23,16a1,1,0,0,1-1,1H15a1,1,0,0,1,0-2h7A1,1,0,0,1,23,16Z"/></svg>
                                </button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="text-gray-400">You have no friends.</li>
                <?php endif; ?>
            </ul>
        </div>
    </main>
</body>
</html>