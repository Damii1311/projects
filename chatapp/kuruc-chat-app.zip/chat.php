<?php
session_start();
require('./php/db.php'); 

$userNickname = $_SESSION['username']; 

$query = "SELECT * FROM friend_requests
        JOIN user ON sender = nickname
         WHERE receiver = ? AND status = 'pending'";
$stmt = $connect->prepare($query);
$stmt->bind_param('s', $userNickname);
$stmt->execute();
$result = $stmt->get_result();
$requests = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Application</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <script defer type="module" src="./src/js/script.js"></script>
    <script defer src="./src/js/chat.js"></script>
</head>

<body class="min-h-screen flex w-full h-full bg-white">
    <?php include("./components/header.php") ?>

    <main class="wrapper shadow-2xl overflow-hidden flex w-full">
        <div class="container max-w-sm w-3/4 border-r border-gray-200">
            <?php include("./components/userProfile.php") ?>
            
            <form id="search" enctype="multipart/form-data" method="POST" action='php/insert.php' class="p-5">
                <div class="search flex items-center space-x-3">
                    <input id="searchInput" name="name" type="text" placeholder="Search for friends" class="search-input w-full px-4 py-3 rounded-xl bg-gray-100 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-black">
                    <button name="button" class="searchBtn p-3 rounded-xl bg-black">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="white">
                            <path d="M380-320q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l224 224q11 11 11 28t-11 28q-11 11-28 11t-28-11L532-372q-30 24-69 38t-83 14Zm0-80q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/>
                        </svg>
                    </button>
                </div>
            </form>
            <p class="error text-red-500 text-center"></p>

            <div id="inbox" class="inbox p-5 space-y-4 overflow-y-auto max-h-[75vh]">
                <h3 class="text-sm text-gray-700">Results</h3>
                <ul class="">
                    <?php if (count($requests) > 0): ?>
                        <?php foreach ($requests as $request): ?>
                            <li class="flex justify-between items-center p-3 rounded-xl">
                                <div class="flex items-center gap-4">
                                    <img src="<?php echo !empty($request['avatar_url']) ? $request['avatar_url'] : "./public/profile.jpg" ?>" class="w-12 h-12 rounded-full object-cover" alt="User">
                                    <p class="nickname truncate capitalize text-[20px] my-auto"><?php echo $request['sender']; ?></p>
                                </div>
                                <div class="flex gap-1">
                                    <form action="php/confirmfriend.php" method="POST">
                                        <input type="hidden" name="sender" value="<?php echo $request['sender']; ?>">
                                        <input type="hidden" name="receiver" value="<?php echo $userNickname; ?>">
                                        <button type="submit" class="bg-black p-2 rounded-xl">
                                            <svg width="25px" height="25px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M5 14L8.23309 16.4248C8.66178 16.7463 9.26772 16.6728 9.60705 16.2581L18 6" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
                                            </svg>
                                        </button>
                                    </form>
                                    <form action="php/declinefriend.php" method="POST" class="h-full">
                                        <input type="hidden" name="sender" value="<?php echo $request['sender']; ?>">
                                        <input type="hidden" name="receiver" value="<?php echo $userNickname; ?>">
                                        <button type="submit" class="bg-black p-2 rounded-xl">
                                            <svg width="25px" height="25px" style="transform: rotate(45deg);" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6 12H18M12 6V18" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="text-gray-400">No friend requests.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <form id="formular" class="container chat-cxntainer w-full flex flex-col" method='POST'>
            <div></div>

            <div class="main flex flex-col gap-2 flex-1 overflow-y-auto p-6" id="messageBody">
            </div>

            <div class="search flex items-center border-t border-gray-200 p-6">
                <input id="input" name="input" type="text" placeholder="Type your message here" class="message-input flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-black">
                <button name="button" class="searchBtn bg-black p-3 rounded-xl ml-3 hover:bg-black transition">
                    <svg fill="#ffffff" width="25px" height="25px" viewBox="0 0 56 56" xmlns="http://www.w3.org/2000/svg"><path d="M 32.7812 52.5508 C 34.4687 52.5508 35.6640 51.0977 36.5312 48.8477 L 51.8829 8.7461 C 52.3048 7.6679 52.5626 6.7070 52.5626 5.9101 C 52.5626 4.3867 51.6016 3.4492 50.0781 3.4492 C 49.2813 3.4492 48.3203 3.6836 47.2423 4.1055 L 6.9296 19.5508 C 4.9609 20.3008 3.4374 21.4961 3.4374 23.2070 C 3.4374 25.3633 5.0780 26.0898 7.3280 26.7695 L 24.2499 31.7383 L 29.1718 48.4492 C 29.8749 50.8164 30.6015 52.5508 32.7812 52.5508 Z M 25.3046 28.1758 L 9.1328 23.2305 C 8.7577 23.1133 8.6406 23.0195 8.6406 22.8555 C 8.6406 22.6914 8.7343 22.5742 9.0859 22.4336 L 40.7733 10.4336 C 42.6484 9.7305 44.4531 8.7930 46.1874 7.9961 C 44.6406 9.2617 42.7187 10.7617 41.4296 12.0508 Z M 33.1562 47.3945 C 32.9687 47.3945 32.8749 47.2305 32.7577 46.8555 L 27.8124 30.6836 L 43.9374 14.5586 C 45.2031 13.2930 46.7733 11.3242 48.0155 9.7305 C 47.2187 11.5117 46.2812 13.3164 45.5546 15.2148 L 33.5546 46.9023 C 33.4140 47.2539 33.3202 47.3945 33.1562 47.3945 Z"/></svg>
                </button>
            </div>
        </form>
    </main>
</body>
</html>
